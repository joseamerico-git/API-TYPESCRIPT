package com.juninho.aplicationapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HidroBikeApplication {

	public static void main(String[] args) {
		SpringApplication.run(HidroBikeApplication.class, args);
	}

}
