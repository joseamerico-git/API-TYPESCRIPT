package com.juninho.aplicationapi.model;

public enum TipoLancamento {
	RECEITA, DESPESA
}
