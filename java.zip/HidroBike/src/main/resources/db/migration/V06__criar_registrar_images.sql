CREATE TABLE IMAGE (
    ID INTEGER NOT NULL PRIMARY KEY auto_increment,
    NOME VARCHAR(100),
    URLIMAGE VARCHAR(100));
   
    
   
INSERT INTO IMAGE (NOME,URLIMAGE) VALUES ("azeite.png","https://pixabay.com/pt/photos/azeite-de-oliva-azeitonas-comida-968657/");