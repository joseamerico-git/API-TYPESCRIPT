package com.juninho.aplicationapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HidroBikeApplicationTests {

	@Test
	void contextLoads() {
	}

}
